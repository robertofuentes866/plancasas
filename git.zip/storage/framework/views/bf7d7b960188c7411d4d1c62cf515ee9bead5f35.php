<?php echo e($slot); ?>

<?php /**PATH C:\Projectos en Laravel\plancasas\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>