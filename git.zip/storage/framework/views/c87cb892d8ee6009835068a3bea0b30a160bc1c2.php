
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="card mb-4">
<div class="card-header">
Editar Agente
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('admin.agenteForm.update',['id'=>$data['agentes']->getId()])); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<div class="row">
<div class="col">
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Privilegio:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<select name="id_privilegio" class="form-control">
     <?php $__currentLoopData = $data["privilegios"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilegio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option <?= $privilegio['id_privilegio'] == $data['agentes']->getIdPrivilegio()?"selected":"" ?> value="<?php echo e($privilegio['id_privilegio']); ?>"><?php echo e($privilegio['nombre']); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select> 
</div>
</div>
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Nombre:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="nombre" value="<?php echo e($data['agentes']->nombre); ?>" type="text" class="form-control">
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Apellidos:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="apellidos" value="<?php echo e($data['agentes']->apellidos); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">email:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="email" value="<?php echo e($data['agentes']->email); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">password:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="password" value="<?php echo e($data['agentes']->password); ?>" type="password" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Cel Tigo:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="cel1" value="<?php echo e($data['agentes']->cel1); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Cel Claro:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="cel2" value="<?php echo e($data['agentes']->cel2); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Foto Agente: <b>[<?php echo e(basename($data['agentes']->foto_agente)); ?>]</b></label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="foto_agente" id="foto_agente" type="file" class="form-control"> 
</div>
</div>

<?php if(!is_null($data['agentes']->foto_agente)): ?>
    <div class="mb-3 row">
    <label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Foto Agente: </label>
    <div class="col-lg-10 col-md-6 col-sm-12"> 
    <img width="<?php echo e($data['thumbAlto']); ?>" height="<?php echo e($data['thumbAncho']); ?>" src="<?php echo e(asset('/storage/agentes/'.$data['agentes']->foto_agente)); ?>"> 
    </div>
    </div>
<?php endif; ?>


</div>
</div>
<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('admin.agenteForm.index')); ?>">Regresar</a></button>
</div>

</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/agenteFormEdit.blade.php ENDPATH**/ ?>