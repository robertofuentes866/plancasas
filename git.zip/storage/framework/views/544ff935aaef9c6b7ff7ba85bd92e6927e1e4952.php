
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="card mb-4">
<div class="card-header">
Editar Precios Propiedad
</div>
<div class="card-body">
<?php if($errors->any()): ?>
    <ul class="alert alert-danger list-unstyled">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>- <?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('admin.preciosCasaForm.update',['id_casa'=>$data['preciosCasa'][0]->id_casa,'id_ofrecimiento'=>$data['preciosCasa'][0]->id_ofrecimiento,
                                        'id_duracion'=>$data['preciosCasa'][0]->id_duracion,'id_recurso'=>$data['preciosCasa'][0]->id_recurso])); ?>" enctype="form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<div class="row">
    <div class="col-3">
                <div class="mb-3 row">
                   <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Prop No.: <b><?php echo e($data['preciosCasa'][0]->casaNumero); ?></b>  </label>
                </div>
    </div>

    <div class="col-3">
                <div class="mb-3 row">
                    <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Ofrecimiento:<b> <?php echo e($data['preciosCasa'][0]->ofrecimiento); ?></b></label>
                </div>

    </div>

    <div class="col-3">
                <div class="mb-3 row">
                    <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Duracion:<b> <?php echo e($data['preciosCasa'][0]->duracion); ?></b></label>
                </div>
    </div>

    <div class="col-3">
                <div class="mb-3 row">
                    <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Recurso:<b> <?php echo e($data['preciosCasa'][0]->recurso); ?></b></label>
                </div>
    </div>

</div>  <!-- Fin de row -->

<div class="row">
    <div class="col-2">
                <div class="mb-3 row">
                <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Precio:</label>
                <div class="col-lg-12 col-md-6 col-sm-12"> 
                <input name="valor" value="<?php echo e($data['preciosCasa'][0]->valor); ?>" type="text" class="form-control"> 
                </div>
                </div>
    </div>
    <div class="col-2">
        <div class="form-check form-check-inline">
            <input <?php echo e($data['preciosCasa'][0]->disponibilidad?"checked":""); ?> class="form-check-input" type="checkbox" name="disponibilidad" id="inlineCheckbox1">
            <label class="form-check-label" for="inlineCheckbox1">Disponibilidad?</label>
        </div>
    </div>
</div>  <!-- Fin de Row -->

<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('admin.preciosCasaForm.index')); ?>">Regresar</a></button>
</div>

</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/preciosCasaFormEdit.blade.php ENDPATH**/ ?>