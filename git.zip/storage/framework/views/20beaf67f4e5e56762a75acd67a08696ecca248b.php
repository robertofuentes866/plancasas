<?php if(isset($_GET['table'])): ?>
   <?php echo e(redirect()->route($_GET['table'])); ?>

<?php endif; ?>

<?php $__env->startSection('title', $viewData["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="card mb-4">
<div class="card-header">
Escoja el formulario
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<form method="GET" action="<?php echo e(route('admin.adminFormsContents')); ?>" enctype="form-data">
<?php echo csrf_field(); ?>
<div class="row">
<div class="col">
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Seleccione Formulario:</label>
<div class="col-lg-10 col-md-6 col-sm-12">
<select name="table" class="form-control">
    <?php $__currentLoopData = $viewData['tablas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabla =>$nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($tabla); ?>"><?php echo e($nombre); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
</div>
</div>
<button type="submit" class="btn btn-primary">Ir</button>
</form>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/adminFormsContents.blade.php ENDPATH**/ ?>