<div class="col-lg-8">
    <div id="title_page_left_container" class="row">
        <p id="title_page_left">
             Propiedades en Grupo
        </p> 
    </div>
    
    <div class="row">
        <div class="col-lg-4 me-5">
            <figure>
                <img src="{{asset('storage/imagenes-grupo/descarga1.jpeg')}}" alt="">
            </figure>
        </div>
        
        <div class="col-lg-4 ms-5">
            <figure>
                <img src="{{asset('storage/imagenes-grupo/descarga2.jpeg')}}" alt="">
            </figure>
        </div>

    </div>

    <div class="row">
        <div class="col-lg-4 me-5">
            <figure>
                <img src="{{asset('storage/imagenes-grupo/descarga3.jpeg')}}" alt="">
            </figure>
        </div>
        
        <div class="col-lg-4 ms-5">
            <figure>
                <img src="{{asset('storage/imagenes-grupo/descarga4.jpeg')}}" alt="">
            </figure>
        </div>

    </div>

    <div class="row">
        <div class="col-lg-4 me-5">
            <figure>
                <img src="{{asset('storage/imagenes-grupo/descarga5.jpeg')}}" alt="">
            </figure>
        </div>
        
        <div class="col-lg-4 ms-5">
            <figure>
                <img src="{{asset('storage/imagenes-grupo/descarga6.jpeg')}}" alt="">
            </figure>
        </div>

    </div>
    
</div>
