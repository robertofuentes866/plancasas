
<?php $__env->startSection('mainTitle',$viewData['titulo']); ?>
<?php $__env->startSection('nav_link_inicio',$viewData['nav_link_inicio']); ?>
<?php $__env->startSection('nav_link_registrar',$viewData['nav_link_registrar']); ?>
<?php $__env->startSection('nav_link_entrar',$viewData['nav_link_entrar']); ?>
<?php $__env->startSection('cuerpo'); ?>

<div class="col-lg-4 bg-primary">
<div class="text-nowrap bg-light border" style="width: 13.5rem; text-align:center; margin:0 auto;margin-bottom:1.2rem">
  FORMULARIO DE BUSQUEDA
</div>
    <form method="post">

            <div class="form-group row">
                <label for="tipo" class="col-lg-4 col-form-label">Tipo</label>
                <div class="col-lg-4">
                    <select name="tipo" id="tipo">
                                    <option value="">** Tipo **</option>
                                    <?php $__currentLoopData = $viewData['tipo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tipo->id_tipo); ?>"><?php echo e($tipo->tipo); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                </div>
            </div>

            <div class="form-group row">
                <label for="ofrecimiento" class="col-lg-4 col-form-label">Ofrecimiento</label>
                <div class="col-lg-4">
                    <select name="ofrecimiento" id="ofrecimiento">
                                    <option value="">*** Ofrecimiento ***</option>
                                    <?php $__currentLoopData = $viewData['ofrecimiento']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofrecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ofrecimiento->id_ofrecimiento); ?>"><?php echo e($ofrecimiento->ofrecimiento); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                </div>
            </div>
               <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-component', [])->html();
} elseif ($_instance->childHasBeenRendered('YUjPbTz')) {
    $componentId = $_instance->getRenderedChildComponentId('YUjPbTz');
    $componentTag = $_instance->getRenderedChildComponentTagName('YUjPbTz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YUjPbTz');
} else {
    $response = \Livewire\Livewire::mount('select-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('YUjPbTz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="form-group row my-3">
                <div class="col-sm-10">
                    <button type="button" class="btn btn-secondary">Enviar</button>
                </div>
            </div>
    </form>
</div>

<div class="col-lg-4 bg-secondary">
<div class="text-nowrap bg-light border" style="width: 13.5rem; text-align:center; margin:0 auto;margin-bottom:1.2rem">
     DESTACADOS
</div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('thumbs-photos', [])->html();
} elseif ($_instance->childHasBeenRendered('hOFyNQd')) {
    $componentId = $_instance->getRenderedChildComponentId('hOFyNQd');
    $componentTag = $_instance->getRenderedChildComponentTagName('hOFyNQd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hOFyNQd');
} else {
    $response = \Livewire\Livewire::mount('thumbs-photos', []);
    $html = $response->html();
    $_instance->logRenderedChild('hOFyNQd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<div class="col-lg-4 bg-primary">
<div class="text-nowrap bg-light border" style="width: 13.5rem; text-align:center; margin:0 auto;margin-bottom:1.2rem">
  PATROCINIO
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plancasas\resources\views/layouts/mainContent.blade.php ENDPATH**/ ?>