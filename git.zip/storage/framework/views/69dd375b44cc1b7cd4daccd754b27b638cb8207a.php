
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>

<!-- copiar desde aqui -->
<?php if(isset($_GET['buscaInfo'])): ?>
   <script>
      window.location.href="<?php echo e('#'.strtoupper($_GET['buscaInfo'])); ?>";
    </script>
<?php endif; ?>
<!-- hasta aqui -->

<div class="card mb-4">
<div class="card-header">
Crear Precios propiedad
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('admin.preciosCasaForm.store')); ?>" enctype="form-data">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-3">
                <div class="mb-3 row">
                <label class="col-lg-10 col-md-6 col-sm-12 col-form-label">Propiedad:</label>
                <div class="col-lg-10 col-md-6 col-sm-12"> 
                <select name="id_casa" class="form-control">
                    <?php $__currentLoopData = $data["casas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($casa['id_casa']); ?>"> <?php echo e($casa['casaNumero']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
                </div>
                </div>
    </div>

    <div class="col-3">
                <div class="mb-3 row">
                <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Ofrecimiento:</label>
                <div class="col-lg-10 col-md-6 col-sm-12"> 
                <select name="id_ofrecimiento" class="form-control">
                    <?php $__currentLoopData = $data["ofrecimientos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofrecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ofrecimiento['id_ofrecimiento']); ?>"> <?php echo e($ofrecimiento['ofrecimiento']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
                </div>
                </div>

    </div>

    <div class="col-3">
                <div class="mb-3 row">
                <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Duracion:</label>
                <div class="col-lg-10 col-md-6 col-sm-12"> 
                <select name="id_duracion" class="form-control">
                    <?php $__currentLoopData = $data["duraciones"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duracion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($duracion['id_duracion']); ?>"> <?php echo e($duracion['duracion']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
                </div>
                </div>
    </div>

    <div class="col-3">
                <div class="mb-3 row">
                <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Recurso:</label>
                <div class="col-lg-10 col-md-6 col-sm-12"> 
                <select name="id_recurso" class="form-control">
                    <?php $__currentLoopData = $data["recursos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($recurso['id_recurso']); ?>"> <?php echo e($recurso['recurso']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
                </div>
                </div>
    </div>

</div>  <!-- Fin de row -->

<div class="row">
    <div class="col-2">
                <div class="mb-3 row">
                <label class="col-lg-6 col-md-6 col-sm-12 col-form-label">Precio:</label>
                <div class="col-lg-12 col-md-6 col-sm-12"> 
                <input name="valor" value="<?php echo e(old('valor')); ?>" type="text" class="form-control"> 
                </div>
                </div>
    </div>

    <div class="col-2">
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" name="disponibilidad" id="inlineCheckbox1">
            <label class="form-check-label" for="inlineCheckbox1">Disponibilidad?</label>
        </div>
    </div>
</div>  <!-- Fin de Row -->

<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('adminForms')); ?>">Regresar</a></button>
</div>

</form>
</div>
</div>

<div class="card">
<div class="card-header">

    <!-- copiar desde aqui -->
    <div class="row">
        <div class="col-lg-8">
        VER PRECIOS PROPIEDAD
        </div>
        <nav class="navbar navbar-light bg-light col-lg-4">
            <div class="container-fluid">
                <form class="d-flex">
                    <?php echo csrf_field(); ?>
                    <select name="buscaInfo" class="form-control">
                        <option value= " ">**Seleccione Casa**</option>
                    <?php $__currentLoopData = $data["buscarFilas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscarFila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($buscarFila->casaNumero); ?>"> <?php echo e($buscarFila->casaNumero); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 


                </select>
                <button class="btn btn-outline-success mx-2" type="submit">Buscar</button>
                </form>
            </div>
        </nav>
    </div>
      <!-- hasta aqui -->

</div>
<div class="card-body">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th scope="col">PROP NUMERO</th>
<th scope="col">OFRECIMIENTO</th>
<th scope="col">DURACION</th>
<th scope="col">RECURSO</th>
<th scope="col">PRECIO</th>
</tr>
</thead>
<tbody>

<!--copiar desde aqui -->
<?php (session(['searchKey'=>'none'])); ?>
<?php $__currentLoopData = $data["relacion"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(! (session('searchKey') == strtoupper($relacion->casaNumero))): ?>
   <tr id="<?php echo e(strtoupper($relacion->casaNumero)); ?>">
   <?php (session(['searchKey'=>strtoupper($relacion->casaNumero)])); ?>
<?php else: ?> 
    <tr>
<?php endif; ?>
<!-- hasta aqui -->
<td><?php echo e($relacion->casaNumero); ?></td>
<td><?php echo e($relacion->ofrecimiento); ?></td>
<td><?php echo e($relacion->duracion); ?></td>
<td><?php echo e($relacion->recurso); ?></td>
<td><?php echo e($relacion->valor); ?></td>
<td> 
    <a class="btn btn-primary" href="<?php echo e(route('admin.preciosCasaForm.edit',['id_casa'=>$relacion->id_casa,'id_ofrecimiento'=>$relacion->id_ofrecimiento,
                                        'id_duracion'=>$relacion->id_duracion,'id_recurso'=>$relacion->id_recurso,'casaNumero'=>$relacion->casaNumero])); ?>">
    <i class="bi-pencil"></i>
    </a>
</td>
<td>
<form action="<?php echo e(route('admin.preciosCasaForm.delete',['id_casa'=>$relacion->id_casa,'id_ofrecimiento'=>$relacion->id_ofrecimiento,
                                        'id_duracion'=>$relacion->id_duracion,'id_recurso'=>$relacion->id_recurso])); ?>" method="post" class="formulario_eliminar">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn btn-danger">
<i class="bi-trash"></i>
</button>
</form>

</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.botonEliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/preciosCasaForm.blade.php ENDPATH**/ ?>