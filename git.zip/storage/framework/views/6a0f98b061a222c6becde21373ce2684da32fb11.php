
<?php $__env->startSection('title', "MENSAJE "); ?>
<?php $__env->startSection('cuerpo'); ?>
   <h1><?php echo e($data['mensaje']); ?></h1>
   <button type="button" onclick="window.location.href='<?php echo e(route($data["ruta"])); ?>'">OK</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/errorPage.blade.php ENDPATH**/ ?>