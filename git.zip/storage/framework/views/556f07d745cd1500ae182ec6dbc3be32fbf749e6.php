<div class="container">
<div class="row row-cols-2">
<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Sierras Doradas K-14 </figcaption>
    </figure>
</div>

<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Sierras Doradas E-7 </figcaption>
    </figure>
</div>   

<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Palmetto 158 </figcaption>
    </figure>
</div>   
<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Los Almendros 89 </figcaption>
    </figure>
</div>   
<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Bosques Cap 37 </figcaption>
    </figure>
</div>   
<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Campo Bello 834 </figcaption>
    </figure>
</div>   
<div class="col">
    <figure> 
        <img class="img-thumbnail" style="padding: 5px;" src="<?php echo e(asset('/storage/images/thumbs/managua/sierras_doradas/01.jpg')); ?>" alt="Sierras Doradas" width="84" height="54">
        <figcaption> Sierras Doradas L-9 </figcaption>
    </figure>
</div>   
    
</div>
</div>

<?php /**PATH C:\xampp_bk\htdocs\plancasas\resources\views/livewire/thumbs-photos.blade.php ENDPATH**/ ?>