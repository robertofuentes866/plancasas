
<?php $__env->startSection('mainTitle',$viewData['titulo']); ?>
<?php $__env->startSection('nav_link_inicio',$viewData['nav_link_inicio']); ?>
<?php $__env->startSection('nav_link_registrar',$viewData['nav_link_registrar']); ?>
<?php $__env->startSection('nav_link_entrar',$viewData['nav_link_entrar']); ?>
<?php $__env->startSection('cuerpo'); ?>

<div class="container" style="background-color:antiquewhite;">
    <div class="row" style="background-color:black; color:cornsilk">
        <p style="text-align:center">RESULTADO DE SU BUSQUEDA</p>
    </div>
    <div class="row">
        <div class="col-4 mt-2 mb-4">
            <?php $comillas = '"'; ?>
            <?php if(isset($imagenes_casas)): ?>
                <div class="row row-cols-2" style="border:2px solid #000 ;background-color:white; margin-left:5px;margin-right:2px">
                        <?php $__currentLoopData = $imagenes_casas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen_casa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <figure wire:click="selectNormalImagen(<?php echo e($comillas.$imagen_casa->foto_normal.$comillas); ?>,
                                    <?php echo e($comillas.$imagen_casa->descripcion.$comillas); ?>)"> 
                                <img class="img-thumbnail" style="padding: 5px"
                                    src="<?php echo e(asset('storage/propiedades/'.$imagen_casa->foto_thumb)); ?>" 
                                    alt="Sierras Doradas" width="84" height="54">
                                <figcaption> <?php echo e($imagen_casa->residencial.' - '.$imagen_casa->casaNumero); ?> </figcaption>
                            </figure>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
 
        <div class="col-8"> 
            <?php if(isset($fotoNormal)): ?>
                <div class="card">
                        <img src="<?php echo e(asset('storage/propiedades/'.$fotoNormal)); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Propiedad Seleccionada</h5>
                            <p class="card-text"> <?php echo e($descripcion); ?></p>
                            <a href="#" class="btn btn-primary">Mas detalles...</a>
                        </div>
                </div>
            <?php endif; ?>    
        </div> 
    </div>

</div>




    </div>
</div> <!-- End bg-primary -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/layouts/busquedaPorFormulario.blade.php ENDPATH**/ ?>