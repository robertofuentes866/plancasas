
<?php $__env->startSection('title', $viewData["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="card mb-4">
<div class="card-header">
Editar privilegios
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('admin.privilegioForm.update', ['id'=> $viewData['privilegios']->getId()])); ?>" enctype="form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<div class="row">
<div class="col">

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Nombre:</label>
<div class="col-lg-10 col-md-6 col-sm-12">
<input name="nombre" value="<?php echo e($viewData['privilegios']->getNombre()); ?>" type="text" class="form-control">
</div>
</div>

<div class="form-check">
<label class="form-check-label" for="flexCheckDefault">Select</label>
  <input name="select" <?php echo e($viewData['privilegios']->getSelect()?"checked":""); ?> class="form-check-input" type="checkbox" id="flexCheckDefault">
</div>

<div class="form-check">
<label class="form-check-label" for="flexCheckDefault">Insert</label>
  <input name="insert" <?php echo e($viewData['privilegios']->getInsert()?"checked":""); ?> class="form-check-input" type="checkbox" id="flexCheckDefault">
</div>

<div class="form-check">
<label class="form-check-label" for="flexCheckDefault">Update</label>
  <input name="update" <?php echo e($viewData['privilegios']->getUpdate()?"checked":""); ?> class="form-check-input" type="checkbox" id="flexCheckDefault">
</div>

<div class="form-check">
<label class="form-check-label" for="flexCheckDefault">Delete</label>
  <input name="delete" <?php echo e($viewData['privilegios']->getDelete()?"checked":""); ?> class="form-check-input" type="checkbox" id="flexCheckDefault">
</div>

<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('admin.privilegioForm.index')); ?>">Regresar</a></button>
</form>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/privilegioFormEdit.blade.php ENDPATH**/ ?>