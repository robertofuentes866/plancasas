
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>

<!-- copiar desde aqui -->
<?php if(isset($_GET['buscaInfo'])): ?>
   <script>
      window.location.href="<?php echo e('#'.strtoupper($_GET['buscaInfo'])); ?>";
    </script>
<?php endif; ?>
<!-- hasta aqui -->
<div class="card mb-4">
<div class="card-header">
Crear Fotos - Propiedad
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.fotosCasaForm.store')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<div class="col">
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Propiedad:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<select name="id_casa" class="form-control">
     <?php $__currentLoopData = $data["casas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($casa['id_casa']); ?>"><?php echo e($casa['casaNumero']); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select> 
</div>
</div>
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Leyenda:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="leyenda" value="<?php echo e(old('leyenda')); ?>" type="text" class="form-control">
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 form-check-label" for="inlineCheckbox5">Es Principal:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input class="form-check-input" type="checkbox" name="es_principal" id="inlineCheckbox5">
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Foto:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="foto_normal" id="foto_normal" type="file" class="form-control"> 
</div>
</div>

<input hidden name="foto_thumb"> 

</div>
</div>
<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('adminForms')); ?>">Regresar</a></button>
</div>

</form>
</div>
</div>




<div class="card">
<div class="card-header">
     <!-- copiar desde aqui -->
    <div class="row">
        <div class="col-lg-8">
        VER FOTOS PROPIEDAD
        </div>
        <nav class="navbar navbar-light bg-light col-lg-4">
            <div class="container-fluid">
                <form class="d-flex">
                    <?php echo csrf_field(); ?>
                    <select name="buscaInfo" class="form-control">
                        <option value= " ">**Seleccione propiedad**</option>
                    <?php $__currentLoopData = $data["buscarFilas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscarFila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($buscarFila->casaNumero); ?>"> <?php echo e($buscarFila->casaNumero); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
                <button class="btn btn-outline-success mx-2" type="submit">Buscar</button>
                </form>
            </div>
        </nav>
    </div>
      <!-- hasta aqui -->
</div>
<div class="card-body">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th scope="col">RESIDENCIAL</th>
<th scope="col">PROPIEDAD</th>
<th scope="col">LEYENDA</th>
</tr>
</thead>
<tbody>
<!--copiar desde aqui -->
<?php (session(['searchKey'=>'none'])); ?>
<?php $__currentLoopData = $data["relacion"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(! (session('searchKey') == strtoupper($relacion->casaNumero))): ?>
   <tr id="<?php echo e(strtoupper($relacion->casaNumero)); ?>">
   <?php (session(['searchKey'=>strtoupper($relacion->casaNumero)])); ?>
<?php else: ?> 
    <tr>
<?php endif; ?>
<!-- hasta aqui -->
<td><?php echo e($relacion->residencial); ?></td>
<td><?php echo e($relacion->casaNumero); ?></td>
<td><?php echo e($relacion->leyenda); ?></td>
<td> 
    <a class="btn btn-primary" href="<?php echo e(route('admin.fotosCasaForm.edit',['id'=>$relacion->id_foto])); ?>">
    <i class="bi-pencil"></i>
    </a>
</td>
<td>
<form action="<?php echo e(route('admin.fotosCasaForm.delete',['id'=>$relacion->id_foto])); ?>" method="post" class="formulario_eliminar">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn btn-danger">
<i class="bi-trash"></i>
</button>
</form>

</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.botonEliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/fotosCasaForm.blade.php ENDPATH**/ ?>