<div>
            <div class="form-group row">
                <label for="tipo" class="col-lg-6 col-form-label">Tipo <span class='requerido'>(Requerido)</span></label>
                
                    <select name="id_tipo" id="tipo">
                                    <option value="">** Tipo de propiedad **</option>
                                   
                                    <?php $__currentLoopData = $viewData['tipo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tipo->id_subtipo); ?>"><?php echo e($tipo->subtipo); ?> </option> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                
            </div>

            <div class="form-group row">
                <label for="ofrecimiento" class="col-lg-8 col-form-label">Compra o Venta <span class="requerido">(Requerido)</span></label>
                
                    <select name="id_ofrecimiento" id="ofrecimiento">
                                    <option value="">*** Desea comprar o alquilar ? ***</option>
                                    <?php $__currentLoopData = $viewData['ofrecimiento']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofrecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ofrecimiento->id_ofrecimiento); ?>"><?php echo e($ofrecimiento->ofrecimiento); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                
            </div>
            
      <div class="form-group row">
         <label for="ciudad" class="col-lg-4 col-form-label">Ciudad</label>
         
               <select wire:model="selectedCiudad" id="ciudad" name="id_ciudad"> 
                     <option value="">**Ubicacion Ciudad**</option>
                     <?php $__currentLoopData = $viewData['ciudades']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ciudad->id_ciudad); ?>"><?php echo e($ciudad->ciudad); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
         
      </div>

      <?php if($selectedCiudad): ?>
      <div class="form-group row">
         <label for="localizacion" class="col-lg-4 col-form-label">Localizacion</label>
        
            <select name="id_localizacion" id="localizacion">
                        <option value="">**Residencial**</option>
                        <?php $__currentLoopData = $localizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($localizacion->id_localizacion); ?>"><?php echo e($localizacion->residencial); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          
      </div>
      <?php endif; ?>
</div>
<?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/livewire/select-component.blade.php ENDPATH**/ ?>