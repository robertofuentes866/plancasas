<?php return array (
  'imagenes-grupo' => 'App\\Http\\Livewire\\ImagenesGrupo',
  'select-component' => 'App\\Http\\Livewire\\SelectComponent',
  'thumbs-photos' => 'App\\Http\\Livewire\\ThumbsPhotos',
);