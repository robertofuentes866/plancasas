
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>

<?php if(isset($_GET['buscaInfo'])): ?> 
   <script>
      window.location.href="<?php echo e('#'.strtoupper($_GET['buscaInfo'])); ?>";
    </script>
<?php endif; ?>

<div class="card mb-4">
<div class="card-header">
Crear Agentes
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.agenteForm.store')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
<div class="col">
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Privilegio:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<select name="id_privilegio" class="form-control">
     <?php $__currentLoopData = $data["privilegios"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilegio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($privilegio['id_privilegio']); ?>"><?php echo e($privilegio['nombre']); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select> 
</div>
</div>
<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Nombre:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="nombre" value="<?php echo e(old('nombre')); ?>" type="text" class="form-control">
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Apellidos:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="apellidos" value="<?php echo e(old('apellidos')); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">email:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="email" value="<?php echo e(old('email')); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">password:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="password" value="<?php echo e(old('password')); ?>" type="password" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Cel Tigo:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="cel1" value="<?php echo e(old('cel1')); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Cel Claro:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="cel2" value="<?php echo e(old('cel2')); ?>" type="text" class="form-control"> 
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Foto Agente:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="foto_agente" id="foto_agente" type="file" class="form-control"> 
</div>
</div>

</div>
</div>
<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('adminForms')); ?>">Regresar</a></button>
</div>

</form>
</div>
</div>




<div class="card">
<div class="card-header">
 <!-- copiar desde aqui -->
 <div class="row">
        <div class="col-lg-8">
        VER AGENTES
        </div>
        <nav class="navbar navbar-light bg-light col-lg-4">
            <div class="container-fluid">
                <form class="d-flex">
                    <?php echo csrf_field(); ?>
                    <select name="buscaInfo" class="form-control">
                        <option value= " ">**Seleccione Email**</option>
                    <?php $__currentLoopData = $data["agentes"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buscarFila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($buscarFila->email); ?>"> <?php echo e($buscarFila->email); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> 
                    <button class="btn btn-outline-success mx-2" type="submit">Buscar</button>
                </form>
            </div>
        </nav>
    </div>
    <!-- hasta aqui -->
</div>
<div class="card-body">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th scope="col">PRIVILEGIO</th>
<th scope="col">NOMBRES</th>
<th scope="col">APELLIDOS</th>
<th scope="col">EMAIL</th>
<th scope="col">CEL. TIGO</th>
<th scope="col">CEL. CLARO</th>
<th scope="col">EDITAR</th>
<th scope="col">BORRAR</th>
</tr>
</thead>
<tbody>
<!--copiar desde aqui -->
<?php (session(['searchKey'=>'none'])); ?>
<?php $__currentLoopData = $data["relacion"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(! (session('searchKey') == strtoupper($relacion->email))): ?>
   <tr id="<?php echo e(strtoupper($relacion->email)); ?>">
   <?php (session(['searchKey'=>strtoupper($relacion->email)])); ?>
<?php else: ?> 
    <tr>
<?php endif; ?>
<!-- hasta aqui -->
<td><?php echo e($relacion->privilegio); ?></td>
<td><?php echo e($relacion->nombre); ?></td>
<td><?php echo e($relacion->apellidos); ?></td>
<td><?php echo e($relacion->email); ?></td>
<td><?php echo e($relacion->cel1); ?></td>
<td><?php echo e($relacion->cel2); ?></td>
<td> 
    <!-- !check_edit(Auth::user()->id)?disable_element}} -->
    <a class="btn btn-primary" href="<?php echo e(route('admin.agenteForm.edit',['id'=>$relacion->id_agente])); ?>">
    <i class="bi-pencil"></i>
    </a>
</td>
<td>
<form action="<?php echo e(route('admin.agenteForm.delete',['id'=>$relacion->id_agente])); ?>" method="post" class="formulario_eliminar">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn btn-danger">
<i class="bi-trash"></i>
</button>
</form>

</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.botonEliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/agenteForm.blade.php ENDPATH**/ ?>