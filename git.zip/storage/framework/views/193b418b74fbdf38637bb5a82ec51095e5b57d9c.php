
<?php $__env->startSection('contenido'); ?>
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('lixo')->html();
} elseif ($_instance->childHasBeenRendered('znYcHyO')) {
    $componentId = $_instance->getRenderedChildComponentId('znYcHyO');
    $componentTag = $_instance->getRenderedChildComponentTagName('znYcHyO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('znYcHyO');
} else {
    $response = \Livewire\Livewire::mount('lixo');
    $html = $response->html();
    $_instance->logRenderedChild('znYcHyO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lixo.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plancasas\resources\views/lixo/lixo.blade.php ENDPATH**/ ?>