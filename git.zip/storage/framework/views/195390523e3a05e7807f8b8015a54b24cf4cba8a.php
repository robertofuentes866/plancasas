<div>
<div class="form-group row">
    <label for="ciudad" class="col-lg-4 col-form-label">Ciudades</label>
    <div class="col-lg-4">
         <select wire:model="selectedCiudad" id="ciudad"> 
               <option value="">*** Ciudad ***</option>
               <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($ciudad->id_ciudad); ?>"><?php echo e($ciudad->ciudad); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select>
    </div>
</div>

<?php if($selectedCiudad): ?>
<div class="form-group row">
   <label for="localizacion" class="col-lg-4 col-form-label">Localizacion</label>
   <div class="col-lg-4">
        <select name="localizacion" id="localizacion">
               <option value="">*** Localizacion ***</option>
                  <?php $__currentLoopData = $localizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($localizacion->id_localizacion); ?>"><?php echo e($localizacion->residencial); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
   </div>
</div>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp_bk\htdocs\plancasas\resources\views/livewire/select-component.blade.php ENDPATH**/ ?>