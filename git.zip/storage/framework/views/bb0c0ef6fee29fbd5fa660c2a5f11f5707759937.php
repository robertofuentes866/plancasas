
<?php $__env->startSection('mainTitle',$viewData['titulo']); ?>
<?php $__env->startSection('nav_link_inicio',$viewData['nav_link_inicio']); ?>
<?php $__env->startSection('nav_link_registrar',$viewData['nav_link_registrar']); ?>
<?php $__env->startSection('nav_link_entrar',$viewData['nav_link_entrar']); ?>
<?php $__env->startSection('cuerpo'); ?>

<div class="col-lg-6 bg-primary">
<div class="text-nowrap bg-light border" style="width: 13.5rem; text-align:center; margin:0 auto;margin-bottom:1.2rem">
  RESULTADO DE SU BUSQUEDA
</div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('thumbs-photos', [])->html();
} elseif ($_instance->childHasBeenRendered('xu3Z2a4')) {
    $componentId = $_instance->getRenderedChildComponentId('xu3Z2a4');
    $componentTag = $_instance->getRenderedChildComponentTagName('xu3Z2a4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xu3Z2a4');
} else {
    $response = \Livewire\Livewire::mount('thumbs-photos', []);
    $html = $response->html();
    $_instance->logRenderedChild('xu3Z2a4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<div class="col-lg-6 bg-secondary">
<div class="text-nowrap bg-light border" style="width: 13.5rem; text-align:center; margin:0 auto;margin-bottom:1.2rem">
     PROPIEDAD SELECCIONADA
</div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views//layouts/resultadoFormulario.blade.php ENDPATH**/ ?>