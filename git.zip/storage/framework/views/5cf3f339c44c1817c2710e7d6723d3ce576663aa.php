<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <form>
        <div>
            <select wire:model="selectedCiudad"> 
                        <option value="">*** Ciudad ***</option>
                        <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ciudad->id_ciudad); ?>"><?php echo e($ciudad->ciudad); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
     <?php if($selectedCiudad): ?>
            <select> 
                        <option value="">*** Localizacion ***</option>
                        <?php $__currentLoopData = $localizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($localizacion->id_localizacion); ?>"><?php echo e($localizacion->residencial); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    <?php endif; ?>
        </div>
    </form>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\plancasas\resources\views/livewire\Lixo.blade.php ENDPATH**/ ?>