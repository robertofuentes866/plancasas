
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="card mb-4">
<div class="card-header">
Editar Foto - Propiedad
</div>
<div class="card-body">
<?php if($errors->any()): ?>
<ul class="alert alert-danger list-unstyled">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>- <?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('admin.fotosCasaForm.update',['id'=>$data['fotosCasa']->getId()])); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<div class="row">
<div class="col">

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Leyenda:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="leyenda" value="<?php echo e($data['fotosCasa']->leyenda); ?>" type="text" class="form-control">
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 form-check-label" for="inlineCheckbox5">Es Principal:</label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input <?php echo e($data['fotosCasa']->getEsPrincipal()?"checked":""); ?> class="form-check-input" type="checkbox" name="es_principal" id="inlineCheckbox5">
</div>
</div>

<div class="mb-3 row">
<label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Foto: <b>[<?php echo e(basename($data['fotosCasa']->foto_normal)); ?>]</b></label>
<div class="col-lg-10 col-md-6 col-sm-12"> 
<input name="foto_normal" id="foto_normal" type="file" class="form-control"> 
</div>
</div>
<?php if(!is_null($data['fotosCasa']->foto_normal)): ?>
    <div class="mb-3 row">
    <label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Foto:</label>
    <div class="col-lg-10 col-md-6 col-sm-12"> 
    <img src="<?php echo e(asset('/storage/propiedades/'.$data['fotosCasa']->foto_normal)); ?>"> 
    </div>
    </div>
<?php endif; ?>

<button type="submit" class="btn btn-primary">Guardar</button>
<button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('admin.fotosCasaForm.index')); ?>">Regresar</a></button>
</div>

</form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/fotosCasaFormEdit.blade.php ENDPATH**/ ?>