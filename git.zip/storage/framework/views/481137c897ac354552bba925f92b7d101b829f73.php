
<?php $__env->startSection('title', $data["title"]); ?>
<?php $__env->startSection('cuerpo'); ?>
<div class="card mb-4">
      <div class="card-header">
          Editar Localizacion
      </div>
      <div class="card-body">
      <?php if($errors->any()): ?>
      <ul class="alert alert-danger list-unstyled">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>- <?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <?php endif; ?>
      <form method="POST" action="<?php echo e(route('admin.localizacionForm.update',['id'=> $data['localizaciones']->getId()])); ?>" enctype="form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="row">
      <div class="col">
          <div class="mb-3 row">
          <label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Ciudad:</label>
          <div class="col-lg-10 col-md-6 col-sm-12"> 
          <select name="id_ciudad" class="form-control">
              <?php $__currentLoopData = $data["ciudades"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?= $ciudad['id_ciudad'] == $data['localizaciones']->getIdCiudad()?"selected":"" ?> value="<?php echo e($ciudad['id_ciudad']); ?>"><?php echo e($ciudad['ciudad']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select> 
          </div>
      </div>
      <div class="mb-3 row">
      <label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Residencial:</label>
      <div class="col-lg-10 col-md-6 col-sm-12"> 

      <input name="residencial" value="<?php echo e($data['localizaciones']->getResidencial()); ?>" type="text" class="form-control">
      </div>
      <div class="mb-3 row">
      <label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Direccion:</label>
      <textarea name="direccion" ><?php echo e($data['localizaciones']->getDireccion()); ?> </textarea> 
      </div>

      <div class="mb-3 row">
      <label class="col-lg-2 col-md-6 col-sm-12 col-form-label">Descripcion:</label>
      <textarea name="descripcion" ><?php echo e($data['localizaciones']->getDescripcion()); ?> </textarea> 
      </div>

      </div>
      </div>
      </div>
      <button type="submit" class="btn btn-primary">Guardar</button>
      <button type="button" class="btn btn-primary"><a style="text-decoration:none;color:beige" href="<?php echo e(route('admin.localizacionForm.index')); ?>">Regresar</a></button>
      </div>

      </form>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projectos en Laravel\plancasas\resources\views/admin/localizacionFormEdit.blade.php ENDPATH**/ ?>